package student;

import mas.agents.Message;
import mas.agents.task.mining.StatusMessage;

public class ConfirmPickup extends Message {
    public ConfirmPickup(StatusMessage message) {

    }
}
